<?php
// PM Computer Centre configuration
session_start();
$host='localhost'; $db='pm_computer_centre'; $user='root'; $pass='';
try { $pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(Throwable $e){ $pdo=null; }
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function logged_in(){return !empty($_SESSION['student_id']) || !empty($_SESSION['admin_id']);}
function admin_only(){if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}}
?>
